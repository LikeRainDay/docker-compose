#! /usr/bin/env python
# -*-coding: utf-8 -*-

import os
import platform

if __name__ == '__main__':
    kernal_name = platform.uname()[0]
    kernal_version = platform.uname()[2].split("-")[0]
    hardware_name = platform.architecture()[0]

    check = True

    if kernal_name != "Linux" or kernal_version < "3.10.0" or hardware_name != "64bit":
        print "A 64-bit installation. Version 3.10 or higher of the Linux kernel"
        check = False

    iptables_version = os.popen("iptables --version | awk '{print $2}'").read().strip("\n")
    if iptables_version and iptables_version < "v1.4":
        print "iptables version 1.4 or higher"
        check = False

    ps_exists = os.popen("ps --version | wc -l").read().strip("\n")
    
    if ps_exists and ps_exists == "0":
        print "A ps executable, usually provided by procps or a similar package"
        check = False

    xz_version = os.popen("xz --version | awk '{print $NF}'").read().strip("\n").split("\n")
    if xz_version and xz_version[0] < "4.9":
        print "XZ Utils 4.9 or higher"
        check = False
        
    docker_installed = os.popen("docker --version | wc -l").read().strip("\n")
    
    if docker_installed and docker_installed > "0":
        print "docker installed"
        check = False

    if check:
        os.system("cp docker-binaries/* /usr/bin/")
        os.system("cp docker.service /usr/lib/systemd/system/")
        print "install docker success"

